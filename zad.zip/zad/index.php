<?php
    header('Location: include/login.php');
    exit();
?>