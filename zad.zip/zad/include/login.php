<?php
    //Страница входа
    session_start();
    
    if (isset($_SESSION['user'])){
        header('Location: profile.php');
        exit();
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Авторизация </title>
    <link rel="stylesheet" href="connect/css/bootstrap.min.css">
    <link rel="stylesheet" href="connect/css/main.css">
</head>
<body>
    <div class="container">
        <h2> Вход в учетную запись</h2>
        <form action="connect/singin.php" method="post">
            <div class="form-group">
            <label>Логин</label>
                <input type="text" placeholder="Введите логин" class="form-control" name="login">
            </div>
            <div class="form-group">
            <label>Пароль</label>
                <input type="password" placeholder="Введите пароль" class="form-control" name="password">
            </div>
            <button type="submit" class="btn btn-primary">Войти</button>
            <p>
                У вас нет аккаунта? - <a href = "registr.php">зарегистрируйтесь</a>
            </p>
            <p class = "msg">
                <?php
                    if (isset($_SESSION['message'])) {
                        echo '<p class="msg">'. $_SESSION['message'] .'</p>';
                        unset($_SESSION['message']);
                    }
                ?>
            </p>
            <p class = "msg1">
                <?php
                    if (isset($_SESSION['message1'])) {
                        echo '<p class="msg1">'. $_SESSION['message1'] .'</p>';
                        unset($_SESSION['message1']);
                    }
                ?>
            </p>
        </form>
    </div>
    <script src="connect/js/bootstrap.bundle.min.js"></script>
</body>
</html>
