<?php
    //Кнопка выхода в профиле
    session_start();
    unset($_SESSION['user']);
    header('Location: ../login.php');
?>