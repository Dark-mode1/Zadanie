<?php
    //Подключение к бд
    
    $connect = mysqli_connect('MySQL-8.4', 'root', '','Users');

    if (!$connect) {
      die("Connection failed: " . $connect->connect_error);
    }
    else{
        print('все ок');
    }
?>