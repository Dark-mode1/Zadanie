<?php
    //Регистрация
    session_start();
    require_once 'connect.php';

    $login = $_POST['login'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';
    
    if ((empty($login)) && (empty($email)) && (empty($password)) && (empty($password_confirm))){
        $_SESSION['message'] = 'Заполните все поля';
        header('Location: ../registr.php');
        exit();
    }
    
    if (empty($login)) {
        $_SESSION['message'] = 'Вы не заполнили логин';
        header('Location: ../registr.php');
        exit();
    }

    if (empty($email)) {
        $_SESSION['message'] = 'Вы не заполнили почту';
        header('Location: ../registr.php');
        exit();
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['message'] = 'Электронная почта введена некорректно';
    header('Location: ../registr.php');
    exit();
    }

    if (empty($password)) {
        $_SESSION['message'] = 'Вы не заполнили пароль';
        header('Location: ../registr.php');
        exit();
    }

    if (empty($password_confirm)) {
        $_SESSION['message'] = 'Вы не заполнили подтверждение пароля';
        header('Location: ../registr.php');
        exit();
    }

    if (strlen($password) < 8) {
        $_SESSION['message'] = 'Пароль должен быть не менее 8 символов';
        header('Location: ../registr.php');
        exit();
    }

    if (!preg_match('/^[A-Za-z0-9]+$/', $password)) {
        $_SESSION['message'] = 'Пароль должен содержать только латинские символы и цифры';
        header('Location: ../registr.php');
        exit();
    }

    if ($password !== $password_confirm) {
        $_SESSION['message'] = 'Пароли не совпадают';
        header('Location: ../registr.php');
        exit();
    }
    
    $search_user = mysqli_query($connect,"SELECT * FROM `User_date` WHERE login = '$login'");
    if (mysqli_num_rows($search_user)>0){
        $_SESSION['message'] = 'Данный логин уже существует';
        header('Location: ../registr.php');
        exit(); 
    }
    
    $search_email = mysqli_query($connect,"SELECT * FROM `User_date` WHERE email = '$email'");
    if (mysqli_num_rows($search_email)>0){
        $_SESSION['message'] = 'Пользователь с данной почтой уже зарегистрирован';
        header('Location: ../registr.php');
        exit(); 
    }
    
    $stmt = mysqli_prepare($connect, "INSERT INTO `User_date` (`id`, `login`, `password`, `email`) VALUES (NULL, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, 'sss', $login, $password, $email);
    mysqli_stmt_execute($stmt);

    $_SESSION['message1'] = 'Вы зарегистрированы';
    header('Location: ../login.php');
    exit();
?>
