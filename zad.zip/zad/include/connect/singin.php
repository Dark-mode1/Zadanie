<?php
    //Вход
    session_start();
    require_once 'connect.php';
    
    $login = $_POST['login'];
    $password = $_POST['password'];
    
    if ((empty($login)) && (empty($password))){
        $_SESSION['message'] = 'Заполните логин и пароль';
        header('Location: ../login.php');
        exit();
    }
    
    if (empty($login)) {
        $_SESSION['message'] = 'Вы не заполнили логин';
        header('Location: ../login.php');
        exit();
    }
    
    if (empty($password)) {
        $_SESSION['message'] = 'Вы не заполнили пароль';
        header('Location: ../login.php');
        exit();
    }
    
    $check_user = mysqli_query($connect,"SELECT * FROM `User_date` WHERE login = '$login' AND password = '$password'");
    if (mysqli_num_rows($check_user)>0){
        $user = mysqli_fetch_assoc($check_user); 
        $_SESSION['user'] = [
            "login" => $user['login'],
            "email" => $user['email']  
        ];
        header('Location: ../profile.php');
    }
    else{
        $_SESSION['message'] = 'Неверный логин или пароль'; 
        header('Location: ../login.php');
        exit();
    }

?>