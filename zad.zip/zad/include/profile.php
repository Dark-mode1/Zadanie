<?php
    //Профиль
    session_start();
    
    if (!$_SESSION['user']){
        header('Location:login.php');
        exit();
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title> Профиль </title>
    <link rel="stylesheet" href="connect/css/bootstrap.min.css">
    <link rel="stylesheet" href="connect/css/profile.css">
</head>
<body>
    <div class="container">
        <h2> Профиль </h2>
        <form action="connect/logout.php" method="post">
            <div class = "form-group">
            <label>Логин: </label>
                <a> <?= $_SESSION['user']['login'] ?> </a>
            </div>
            <div class = "form-group">
            <label>Почта: </label>
                <a href="#"> <?= $_SESSION['user']['email'] ?> </a>
            </div>
            <button type="submit" class="btn btn-primary"> Выход </button>
        </form>
    </div>
    <script src="connect/js/bootstrap.bundle.min.js"></script>
</body>
</html>