<?php
    //Страница регистрации
    session_start();
    
    if (isset($_SESSION['user'])){
        header('Location: profile.php');
        exit();
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title> Регистрация </title>
    <link rel="stylesheet" href="connect/css/bootstrap.min.css">
    <link rel="stylesheet" href="connect/css/main.css">
</head>
<body>
    <div class="container">
        <h2> Регистрация учетной записи </h2>
        <form action="connect/singup.php" method="post">
            <div class="form-group">
            <label>Логин</label>
                <input type="text" placeholder="Введите логин" class="form-control" name="login">
            </div>
            <div class="form-group">
            <label>Почта</label>
                <input type="email" placeholder="Введите почту" class="form-control" name="email">
            </div>
            <div class="form-group">
            <label>Пароль</label>
                <input type="password" placeholder="Введите пароль" class="form-control" name="password">
            </div>
            <div class="form-group">
            <label>Подтверждение пароля</label>
                <input type="password" placeholder="Подтвердите пароль" class="form-control" name="password_confirm">
            </div>
            <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
            <p>
                У вас аккаунт? - <a href = "login.php">авторизируйтесь</a>
            </p>
                <p class = "msg">
                <?php
                    if (isset($_SESSION['message'])) {
                        echo '<p class="msg">'. $_SESSION['message'] .'</p>';
                        unset($_SESSION['message']);
                    }
                ?>
            </p>
        </form>
    </div>
    <script src="connect/js/bootstrap.bundle.min.js"></script>
</body>
</html>